
// Import file path 
import  Footer  from "./Components/footer";
import Nav from "./Components/Nav";

function App() {

  return (
    <div>
      <Nav />
      <Footer />
    </div>
  )
}

export default App;